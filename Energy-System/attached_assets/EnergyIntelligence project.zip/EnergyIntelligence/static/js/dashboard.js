let chart;

function updateLastUpdated() {
    const now = new Date();
    document.getElementById('last-updated').textContent = 
        now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
}

function updateDashboard() {
    fetch('/api/data')
        .then(response => response.json())
        .then(data => {
            // Update metrics with animations
            const metrics = {
                'current-production': data.energy_produced,
                'current-consumption': data.energy_consumed,
                'efficiency': data.efficiency,
                'current-load': data.current_load
            };

            Object.entries(metrics).forEach(([id, value]) => {
                const el = document.getElementById(id);
                el.textContent = value.toFixed(1);
            });

            // Update chart
            const labels = data.historical_data.map(d => d.timestamp);
            const productionData = data.historical_data.map(d => d.produced);
            const consumptionData = data.historical_data.map(d => d.consumed);

            chart.data.labels = labels;
            chart.data.datasets[0].data = productionData;
            chart.data.datasets[1].data = consumptionData;
            chart.update('show');

            updateLastUpdated();
        });
}

document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('energyChart').getContext('2d');

    // Chart configuration
    chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Energy Produced',
                borderColor: 'rgb(25, 135, 84)',
                backgroundColor: 'rgba(25, 135, 84, 0.1)',
                borderWidth: 2,
                tension: 0.4,
                data: [],
                fill: true
            }, {
                label: 'Energy Consumed',
                borderColor: 'rgb(220, 53, 69)',
                backgroundColor: 'rgba(220, 53, 69, 0.1)',
                borderWidth: 2,
                tension: 0.4,
                data: [],
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                intersect: false,
                mode: 'index'
            },
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        usePointStyle: true,
                        padding: 20
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    padding: 12,
                    cornerRadius: 8
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Energy (kWh)'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });

    // Update every 30 seconds
    setInterval(updateDashboard, 30000);
    updateDashboard();
    updateLastUpdated();
});